Student Performance Prediction with Decision Tree

Features

-Predicts student performance using a Decision Tree.
-Generates Visualizations:
Decision Tree Structure: Shows how the model decides.
-Actual vs. Predicted Plot: Compares predictions to actual values.
-Feature Importance Plot: Highlights which features matter most.
-Saves the model and encoder for reuse.
-Includes error handling for robust predictions.
